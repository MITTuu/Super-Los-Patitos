﻿using Prototipo.Modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prototipo.Prototipo
{
    public partial class PersonalModificar : Form
    {
        private Cnx conexion;
        public PersonalModificar()
        {
            InitializeComponent();
            conexion = new Cnx();

            // Suscribir el evento CellClick
            dgvPersonal.CellClick += new DataGridViewCellEventHandler(dgvPersonal_CellClick);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tbNombre.Text = "Dylan";
            tbApellido1.Text = "Montiel";
            tbApellido2.Text = "Zúñiga";
            tbIdentificación.Text = "703050437";
            tbCorreo.Text = "dylanmmz01@gmail.com";
            tbContrasenia.Text = "abc123";
            tbTelefono.Text = "60234565";
            cbRol.SelectedIndex = 1;
            cbTipoI.SelectedIndex = 1;
        }

        private void btnModificar_Click_1(object sender, EventArgs e) {
            // Obtener los valores actualizados de los campos del formulario
            string nombre = tbNombre.Text;
            string primerApellido = tbApellido1.Text;
            string segundoApellido = tbApellido2.Text;
            string correo = tbCorreo.Text;
            string contrasena = tbContrasenia.Text;
            string telefono = tbTelefono.Text;
            int estado = cbRol.SelectedIndex; // Define cómo obtener el estado, por ejemplo, de un control CheckBox
            string identificacion = tbIdentificación.Text;
            int idTipoIdentificacion = cbTipoI.SelectedIndex + 1; // Ajusta según la lógica de tu ComboBox
            int idRol = cbRol.SelectedIndex + 1; // Ajusta según la lógica de tu ComboBox
            int idPersonal = ObtenerIdPersonalSeleccionado(); // Define esta función para obtener el idPersonal seleccionado

            if (idPersonal != -1) {
                if (conexion.UpdatePersonal(idPersonal, nombre, primerApellido, segundoApellido, correo, contrasena, telefono, estado, identificacion, idTipoIdentificacion, idRol)) {
                    MessageBox.Show("Usuario modificado con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Actualizar la vista de los datos después de la modificación
                    LoadPersonalData();
                } else {
                    MessageBox.Show("No se pudo modificar el usuario.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private int ObtenerIdPersonalSeleccionado() {
            // Asegurarse de que hay al menos una fila seleccionada
            if (dgvPersonal.SelectedRows.Count > 0) {
                
                // Obtener el valor del idPersonal de la fila seleccionada
                int idPersonal = Convert.ToInt32(dgvPersonal.SelectedRows[1].Cells["idPersonal"].Value);
                return idPersonal;
            } else {
                // Si no hay filas seleccionadas, mostrar un mensaje de error y devolver -1
                MessageBox.Show("No se ha seleccionado ningún personal.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }


        private void PersonalModificar_Load(object sender, EventArgs e) {
            LoadPersonalData();
        }

        

        private void LoadPersonalData() {
            DataTable personalData = conexion.GetAllPersonal();
            if (personalData != null) {
                dgvPersonal.DataSource = personalData;
                dgvPersonal.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                // Agregar una columna de botones si no existe
                if (!dgvPersonal.Columns.Contains("Acción")) {
                    DataGridViewButtonColumn btnColumn = new DataGridViewButtonColumn();
                    btnColumn.HeaderText = "Acción";
                    btnColumn.Text = "Mostrar";
                    btnColumn.Name = "Acción";
                    btnColumn.UseColumnTextForButtonValue = true;
                    dgvPersonal.Columns.Add(btnColumn);
                }
            } else {
                MessageBox.Show("No se pudieron cargar los datos del personal.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvPersonal_CellContentClick(object sender, DataGridViewCellEventArgs e) {

        }
        private void dgvPersonal_CellClick(object sender, DataGridViewCellEventArgs e) {
            // Asegurarse de que el índice de la columna sea el de la columna del botón
            if (e.ColumnIndex == dgvPersonal.Columns["Acción"].Index && e.RowIndex >= 0) {
                // Obtener la fila actual
                DataGridViewRow row = dgvPersonal.Rows[e.RowIndex];

                // Asignar los valores de las celdas a los TextBoxes y ComboBoxes
                tbNombre.Text = row.Cells[2].Value.ToString();
                tbApellido1.Text = row.Cells[3].Value.ToString();
                tbApellido2.Text = row.Cells[4].Value.ToString();
                tbCorreo.Text = row.Cells[5].Value.ToString();
                tbContrasenia.Text = row.Cells[6].Value.ToString();
                tbTelefono.Text = row.Cells[7].Value.ToString();
                tbIdentificación.Text = row.Cells[9].Value.ToString();
                cbTipoI.SelectedIndex = Convert.ToInt32(row.Cells[10].Value);
                cbRol.SelectedIndex = Convert.ToInt32(row.Cells[11].Value);

            }
        }


        private void label2_Click(object sender, EventArgs e) {

        }

        private void label3_Click(object sender, EventArgs e) {

        }

        private void textBox2_TextChanged(object sender, EventArgs e) {

        }
    }
}
